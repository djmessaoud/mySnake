﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace MySnake
{
    public class Snake
    {
        public Rectangle[] Body;
        private int x = 0, y = 0, h = 10, w = 10;

        public Snake()
        {
            Body = new Rectangle[1];
            Body[0] = new Rectangle(x, y, w, h);
        }
        public void Draw()
        {
            for (int i=Body.Length-1;i>0;i--)
            {
                Body[i] = Body[i - 1];
            }
        }
        public void Draw(Graphics graphics)
        {
            graphics.FillRectangles(Brushes.Aqua, Body);

        }
        public void Move(int direction) // 0up,1left,2down,3right //
        {
            Draw();
            switch(direction)
            {
                case 0:
                    Body[0].Y -= 10;
                    break;
                case 1:
                    Body[0].X -= 10;
                    break;
                case 2:
                    Body[0].Y += 10;
                    break;
                case 3:
                    Body[0].X += 10;
                    break;
            }
        }
        public void Grow()
        {   
            List<Rectangle> temp = Body.ToList();
            temp.Add(new Rectangle(Body[Body.Length - 1].X, Body[Body.Length - 1].Y, w, h));
            Body = temp.ToArray();

        }

    }
}
