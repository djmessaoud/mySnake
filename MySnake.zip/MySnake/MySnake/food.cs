﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace MySnake
{
    public class food
    {
        public Rectangle Piece;
        private int x, y, h = 10, w = 10;
        public food(Random rand)
        {
            Generate(rand);
            Piece = new Rectangle(x, y, w, h);
        }
        public void Draw(Graphics graphics)
        {
            Piece.X = x;
            Piece.Y = y;
            graphics.FillRectangle(Brushes.Violet, Piece);  
        }
        public void Generate(Random rand)
        {
            x = rand.Next(0, 25) * 10;
            y = rand.Next(0, 15) * 10;

        }
    }
}
