﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MySnake
{
    public partial class main : Form
    {
        private int direction = 2;
        private int score = 1;
        private Timer gameLoop = new Timer();
        private Random rand = new Random();
        private Graphics graphics;
        private Snake snake;
        private food Food;

        public main()
        {
            InitializeComponent();
            snake = new Snake();
            Food = new food(rand);
            gameLoop.Interval = 75;
            gameLoop.Tick += Update;

        }

        private void main_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyData)
            {
                case Keys.Enter:
                    if (label1.Visible)
                    {
                        label1.Visible = false;
                        gameLoop.Start();
                    }
                    break;
                case Keys.Space:
                    if (!label1.Visible)
                    {
                        gameLoop.Enabled = (gameLoop.Enabled) ? false : true; 
                    }
                    break;
                case Keys.Right:
                    if (direction != 1) direction = 3;
                    break;
                case Keys.Left:
                    if (direction != 3) direction = 1;
                    break;
                case Keys.Up:
                    if (direction != 2) direction = 0;
                    break;
                case Keys.Down:
                    if (direction != 0) direction = 2;
                    break;

            }
        }

        private void main_Paint(object sender, PaintEventArgs e)
        {
            graphics = this.CreateGraphics();
            snake.Draw(graphics);
            Food.Draw(graphics);

        }
        private void Update(object sender, EventArgs e)
        {
            this.Text = string.Format("Sn4ke - Score {0}", score);
            snake.Move(direction);
            for (int i=1;i<snake.Body.Length-1;i++)
            {
                if (snake.Body[0].IntersectsWith(snake.Body[i]))
                    Restart();
            }
            if ((snake.Body[0].X < 0) || (snake.Body[0].Y > 229)) Restart();
            if ((snake.Body[0].Y < 0) || (snake.Body[0].X > 306)) Restart();
            if (snake.Body[0].IntersectsWith(Food.Piece))
            {
                score++;
                snake.Grow();
                Food.Generate(rand);
            }
            this.Invalidate();
        }
        private void Restart ()
        {
            gameLoop.Stop();
            graphics.Clear(SystemColors.Control);
            snake = new Snake();
            Food = new food(rand);
            direction = 2;
            score = 1;
            label1.Visible = true; 

        }
    }
}
